package com.alibaba.service;

public class Test6 extends Person{
	public void show(){
		System.out.println("7");
	}
	public void show02(){
		System.out.println("8");
	}
}
