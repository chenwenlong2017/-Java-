package com.alibaba.service;

public class Dog extends Animal{
	public void sleep(){
		System.out.println("Dog sleep");
	}
	public void eat(){
		System.out.println("Dog eat");
	}
}
