package com.alibaba.service;

public class Student {
	static String name="zhangsan";
	int age;
	String addr;
	private String sex;
	
	public String getSex() {
		return sex;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setSex(String sex) {
		if(sex.equals("��")||sex.equals("Ů"))
			this.sex=sex;
		else
			System.out.println("������Ա�"+sex+"������");
		this.sex = sex;
	}
	
	/*public void setSex(String sex){
		if(sex.equals("��")||sex.equals("Ů")){
			this.sex=sex;
		}
	}*/
	public Student(){}
	
	public Student(String name,int age,String addr){
		this.name=name;
		this.age=age;
		this.addr=addr;
	}
	public void show(){
		print();//�Ǿ�̬�������Է��ʾ�̬����
		System.out.println(name);
		System.out.println("------>");
		System.out.println(name+"\t"+age+"\t"+addr);
	}
	
	public static void print(){ 
		System.out.println(name);
		System.out.println("Student.print()");
	}
}
