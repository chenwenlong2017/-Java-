package com.alibaba.service;

import java.util.Scanner;

public class Test4 {
	public static void main(String[] args) {
		boolean flag=10>20?true:false;
		boolean f=10<5|10>2?true:false;
		String f4="Hello";
		System.out.println(f4.equals("Hello"));
		Scanner input=new Scanner(System.in); 
		String x=input.next();
		boolean y=f4.equals(x);
		System.out.println(flag);
		System.out.println(f);
		System.out.println(y);
	}
}
