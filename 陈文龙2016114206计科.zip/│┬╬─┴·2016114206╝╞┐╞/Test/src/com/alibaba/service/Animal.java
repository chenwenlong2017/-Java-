package com.alibaba.service;

public class Animal {
	public void sleep(){
		System.out.println("sleep");
	}
	public void eat(){
		System.out.println("eat");
	}
}
