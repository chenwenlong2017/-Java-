package com.alibaba.service;

public class Copy_Student {
	String name;
	private int old;
	String sex;
	public int getOld() {
		return old;
	}
	public void setOld(int old) {
		this.old = old;
	}
	public void show(){
		System.out.println("name:"+name+";old:"+old+";sex:"+sex);
	}
	public String getname(){
		return name;
	}
	public Copy_Student(String name,int old){
		this.name=name;
		this.old=old;
	}
}
