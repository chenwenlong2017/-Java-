package com.alibaba.service;

public abstract class Person {
	public abstract void show();
	public abstract void show02();
}
