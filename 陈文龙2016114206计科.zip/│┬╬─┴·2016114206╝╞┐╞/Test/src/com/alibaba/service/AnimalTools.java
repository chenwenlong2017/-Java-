package com.alibaba.service;

public class AnimalTools {
	public static void sleep(Animal a){
		System.out.println(a+"is sleeping");
	}
}
