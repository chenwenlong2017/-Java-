package com.alibaba.service;

import java.util.Scanner;

public class Login{ 
	public static void main(String[] args) {
		System.out.println("====���˵�====");
		Scanner input = new Scanner(System.in);
		String username;
		String userpwd;	
		username="17856170767";
		userpwd="88888888";
		System.out.println("�������û�����");
		String input1=input.next();
		System.out.println("���������룺");
		String input2=input.next();
		if(input1.equals(username)&&input2.equals(userpwd)){
			System.out.println("login success");
			}
		else{
			System.out.println("login failure");
			}
		}
}


