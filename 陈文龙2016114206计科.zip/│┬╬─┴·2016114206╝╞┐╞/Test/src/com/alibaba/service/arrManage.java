package com.alibaba.service;

import java.util.Arrays;

public class arrManage {
	int[] a={2,9,4};
	public int[] arrsort(){
		Arrays.sort(a);
		return a;
	}
	
}
