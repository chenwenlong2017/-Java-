package com.alibaba.service;

import java.util.Scanner;

public class Test5 {
	/**
	 * random numbers
	 * @param args
	 */
	public static void main(String[] args) {
		/*int num=(int)(Math.random()*10);
		System.out.println(num);
		Student[] stu=new Student[4];
		int age=20;
		Scanner input=new Scanner(System.in);
		for(int i=0;i<4;i++){
			System.out.println("�������"+(i+1)+"��ѧ��������");
			age=input.nextInt();
			stu[i].setAge(age);
		}*/
		Student stud=new Student();
		System.out.println(stud.name);
		Test6 aa=new Test6();
		aa.show();
	}
}


