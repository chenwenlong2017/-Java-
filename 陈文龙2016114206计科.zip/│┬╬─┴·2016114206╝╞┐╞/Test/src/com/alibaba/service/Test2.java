package com.alibaba.service;

import java.util.Scanner;

public class Test2 {
	public static void main(String[] args){
		int a=5;
		System.out.println(a);
		System.out.println(Byte.MAX_VALUE);
		System.out.println(Byte.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Short.MAX_VALUE);
		System.out.println(Short.MIN_VALUE);
		long c=123456789L;
		System.out.println(c);
		float d=0.5F;
		System.out.println(d);
		String str="abcdefghijk";
		System.out.println(str);
		boolean flag1=true;
		boolean flag2=false;
		System.out.println(flag1);
		System.out.println(flag2);
		boolean flag=10>20?true:false;
		System.out.println(flag);
		int flag11=50<60?2:1;
		System.out.println(flag11);
		if(flag11>1&4>5)//�Ƕ�·�����
			System.out.println("yes");
		String a1="Unit1";
		System.out.println(a1.equals("Unit1"));
		System.out.println("Please enter the paragraph:");
		Scanner scanner=new Scanner(System.in);
		String name=scanner.next();
		System.out.println(name);
		System.out.println("Please enter the Integer:");
		int name2=scanner.nextInt();
		System.out.println(name2);
		System.out.println("Please enter the String:");
		String name3=scanner.next();
		System.out.println(name3);
		Double name4=scanner.nextDouble();

	}
}