package com.alibaba.service;

public class Test7 {
	public static void main(String[] args) {
		Dog dog=new Dog();
		AnimalTools.sleep(dog);
		Cat cat=new Cat();
		cat.eat();
	}

}
