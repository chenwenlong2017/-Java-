package com.alibaba.service;

public class StudentTest {
	public static void main(String[] args) {
		Student stu=new Student("liminh",21,"jiji");
		stu.setSex("��");
		System.out.println(stu.name);
		String sex=stu.getSex();
		System.out.println(sex);
	}
}
