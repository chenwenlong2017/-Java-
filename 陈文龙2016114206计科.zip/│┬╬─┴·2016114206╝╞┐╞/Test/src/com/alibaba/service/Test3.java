package com.alibaba.service;

import java.util.Scanner;

public class Test3 {
	public static void main(String[] args) {
		System.out.println("Please enter you score:");
		Scanner scanner=new Scanner(System.in);
		int num=scanner.nextInt();
		if(num>90)
			System.out.println("You are very good!");
		else if(num>80)
			System.out.println("You are in middle class");
		else
			System.out.println("You are just soso");
		System.out.println("Game over!");
	}
}
